# Readme
This is a simple maven project with no code just to test the conventional commits plugin.
